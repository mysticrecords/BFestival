<?php

$webserver = "*******";
$user = "*******";
$pw = "*******";
$db = "*******";

$conn = new mysqli($webserver, $user, $pw, $db);

if($conn->connect_error) {
    echo "Connection failed".$conn->connect_error;
}

?>
